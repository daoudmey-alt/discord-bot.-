const { SlashCommandBuilder, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ChannelSelectMenuBuilder, RoleSelectMenuBuilder, StringSelectMenuBuilder } = require('discord.js');
const { getSettings, updateSettings, listTicketTypes, createTicketType, listApplications, getStats, log, getApplication, updateApplicationDecision, rejectedCount, banApplicant, unbanApplicant, isBanned } = require('../services/database');
const { isManager, isBotOwner } = require('../utils/permissions');
const { createTicket } = require('../services/tickets');
const { cut } = require('../utils/arabic');
const config=require('../config');

function setupEmbed(guild){
 const s=getSettings(guild.id);
 return new EmbedBuilder().setTitle('⚙️ إعداد Best.Daod').setDescription('من هنا يتم ضبط البوت لهذا السيرفر فقط. يمكنك التخطي وإكمال الإعداد لاحقًا.').addFields(
  {name:'قناة الأوامر',value:s.command_channel_id?`<#${s.command_channel_id}>`:'غير محددة',inline:true},
  {name:'قناة السجلات',value:s.logs_channel_id?`<#${s.logs_channel_id}>`:'غير محددة',inline:true},
  {name:'رتبة الإدارة',value:s.admin_role_id?`<@&${s.admin_role_id}>`:'غير محددة',inline:true},
  {name:'الصيانة',value:s.maintenance?'مفعلة':'متوقفة',inline:true},
  {name:'الحماية',value:s.protection_enabled?'مفعلة':'متوقفة',inline:true},
  {name:'التحقق',value:s.verification_enabled?'مفعل':'متوقف',inline:true}
 ).setFooter({text:'Best.Daod | TEAM MAJID'});
}
function setupRow(){return new ActionRowBuilder().addComponents(
 new ButtonBuilder().setCustomId('setup_command').setLabel('اختيار قناة الأوامر').setStyle(ButtonStyle.Primary),
 new ButtonBuilder().setCustomId('setup_logs').setLabel('اختيار قناة السجلات').setStyle(ButtonStyle.Primary),
 new ButtonBuilder().setCustomId('setup_role').setLabel('اختيار رتبة الإدارة').setStyle(ButtonStyle.Primary),
 new ButtonBuilder().setCustomId('setup_done').setLabel('إنهاء الإعداد').setStyle(ButtonStyle.Success),
 new ButtonBuilder().setCustomId('setup_reset').setLabel('إعادة الإعداد').setStyle(ButtonStyle.Danger),
 new ButtonBuilder().setCustomId('setup_skip').setLabel('تخطي الآن').setStyle(ButtonStyle.Secondary)
);}

const commands=[
 new SlashCommandBuilder().setName('apply').setDescription('تقديم طلب إضافة Best.Daod إلى سيرفرك'),
 new SlashCommandBuilder().setName('setup').setDescription('إعداد Best.Daod لهذا السيرفر'),
 new SlashCommandBuilder().setName('tickets').setDescription('فتح لوحة التذاكر'),
 new SlashCommandBuilder().setName('ticket-type').setDescription('إنشاء نوع تذكرة جديد').addStringOption(o=>o.setName('name').setDescription('اسم نوع التذكرة').setRequired(true)).addStringOption(o=>o.setName('description').setDescription('وصف نوع التذكرة').setRequired(false)),
 new SlashCommandBuilder().setName('maintenance').setDescription('تفعيل أو إيقاف وضع الصيانة').addBooleanOption(o=>o.setName('enabled').setDescription('الحالة الجديدة').setRequired(true)),
 new SlashCommandBuilder().setName('protection').setDescription('عرض حالة الحماية أو إدارتها').addBooleanOption(o=>o.setName('enabled').setDescription('الحالة الجديدة').setRequired(false)),
 new SlashCommandBuilder().setName('welcome').setDescription('ضبط الترحيب والتوديع').addBooleanOption(o=>o.setName('enabled').setDescription('تفعيل الترحيب').setRequired(true)),
 new SlashCommandBuilder().setName('verify').setDescription('ضبط نظام التحقق').addBooleanOption(o=>o.setName('enabled').setDescription('تفعيل التحقق').setRequired(true)),
 new SlashCommandBuilder().setName('security').setDescription('عرض حالة الحماية الأمنية'),
 new SlashCommandBuilder().setName('stats').setDescription('عرض إحصائيات Best.Daod'),
 new SlashCommandBuilder().setName('admin').setDescription('لوحة إدارة Best.Daod').setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
];

async function handleCommand(interaction){
 if(interaction.commandName==='apply') return apply(interaction);
 if(!interaction.guild) return interaction.reply({content:'❌ هذا الأمر متاح داخل السيرفر فقط.',ephemeral:true});
 if(interaction.commandName==='setup'){
   if(!isManager(interaction.member,interaction.guild)) return interaction.reply({content:'❌ ليس لديك صلاحية لإدارة Best.Daod في هذا السيرفر.',ephemeral:true});
   return interaction.reply({embeds:[setupEmbed(interaction.guild)],components:[setupRow()],ephemeral:true});
 }
 if(interaction.commandName==='tickets'){
   const types=listTicketTypes(interaction.guild.id);
   if(!types.length) return interaction.reply({content:'⚠️ لا توجد أنواع تذاكر مفعلة حاليًا.',ephemeral:true});
   const menu=new StringSelectMenuBuilder().setCustomId('ticket_type_select').setPlaceholder('اختر نوع التذكرة').addOptions(types.slice(0,25).map(t=>({label:cut(t.name,100),value:String(t.id),description:cut(t.description||'فتح تذكرة',100)})));
   return interaction.reply({embeds:[new EmbedBuilder().setTitle('🎫 مركز التذاكر').setDescription('اختر نوع التذكرة المناسب من القائمة أدناه.')],components:[new ActionRowBuilder().addComponents(menu)]});
 }
 if(interaction.commandName==='ticket-type'){
   if(!isManager(interaction.member,interaction.guild)) return interaction.reply({content:'❌ ليس لديك صلاحية إدارة أنواع التذاكر.',ephemeral:true});
   const t=createTicketType({guild_id:interaction.guild.id,name:interaction.options.getString('name'),description:interaction.options.getString('description')||''});
   log(interaction.guild.id,interaction.user.id,'ticket_type_create',`تم إنشاء نوع تذكرة #${t.id}`);
   return interaction.reply({content:`✅ تم إنشاء نوع التذكرة **${t.name}**.`,ephemeral:true});
 }
 if(interaction.commandName==='maintenance'){
   if(!isManager(interaction.member,interaction.guild)) return interaction.reply({content:'❌ لا تملك صلاحية وضع الصيانة.',ephemeral:true});
   const enabled=interaction.options.getBoolean('enabled');
   updateSettings(interaction.guild.id,{maintenance:enabled?1:0}); log(interaction.guild.id,interaction.user.id,'maintenance_change',enabled?'تم التفعيل':'تم الإيقاف');
   return interaction.reply(`🛠️ تم ${enabled?'تفعيل':'إيقاف'} **وضع الصيانة**.`);
 }
 if(interaction.commandName==='protection'){
   if(!isManager(interaction.member,interaction.guild)) return interaction.reply({content:'❌ لا تملك صلاحية إدارة الحماية.',ephemeral:true});
   const v=interaction.options.getBoolean('enabled');
   if(v===null) return interaction.reply({content:`🛡️ الحماية حاليًا **${getSettings(interaction.guild.id).protection_enabled?'مفعلة':'متوقفة'}**.`,ephemeral:true});
   updateSettings(interaction.guild.id,{protection_enabled:v?1:0}); log(interaction.guild.id,interaction.user.id,'protection_setting',v?'تفعيل':'إيقاف');
   return interaction.reply(`🛡️ تم ${v?'تفعيل':'إيقاف'} إعداد الحماية.`);
 }
 if(interaction.commandName==='welcome'){
   if(!isManager(interaction.member,interaction.guild)) return interaction.reply({content:'❌ لا تملك صلاحية إدارة الترحيب.',ephemeral:true});
   const v=interaction.options.getBoolean('enabled'); updateSettings(interaction.guild.id,{welcome_enabled:v?1:0});
   return interaction.reply(`👋 تم ${v?'تفعيل':'إيقاف'} نظام الترحيب.`);
 }
 if(interaction.commandName==='verify'){
   if(!isManager(interaction.member,interaction.guild)) return interaction.reply({content:'❌ لا تملك صلاحية إدارة التحقق.',ephemeral:true});
   const v=interaction.options.getBoolean('enabled'); updateSettings(interaction.guild.id,{verification_enabled:v?1:0});
   return interaction.reply(`🛡️ تم ${v?'تفعيل':'إيقاف'} نظام التحقق.`);
 }
 if(interaction.commandName==='security'){
   const s=getSettings(interaction.guild.id); return interaction.reply({content:`🛡️ **حالة الحماية**\nالحماية الأساسية: ${s.protection_enabled?'مفعلة':'متوقفة'}\nوضع الصيانة: ${s.maintenance?'مفعل':'متوقف'}`,ephemeral:true});
 }
 if(interaction.commandName==='stats'){
   if(!isManager(interaction.member,interaction.guild) && !isBotOwner(interaction.user.id)) return interaction.reply({content:'❌ الإحصائيات الإدارية غير متاحة لك.',ephemeral:true});
   const s=getStats(); return interaction.reply({embeds:[new EmbedBuilder().setTitle('📊 إحصائيات Best.Daod').addFields({name:'طلبات إضافة البوت',value:String(s.applications),inline:true},{name:'السيرفرات',value:String(s.servers),inline:true},{name:'قيد الانتظار',value:String(s.pending),inline:true},{name:'مقبولة',value:String(s.approved),inline:true},{name:'مرفوضة',value:String(s.rejected),inline:true},{name:'المحظورون',value:String(s.banned),inline:true})],ephemeral:true});
 }
 if(interaction.commandName==='admin'){
   if(!isBotOwner(interaction.user.id)) return interaction.reply({content:'❌ هذه اللوحة مخصصة لإدارة Best.Daod العليا.',ephemeral:true});
   const s=getStats(); return interaction.reply({embeds:[new EmbedBuilder().setTitle('🛡️ لوحة إدارة Best.Daod').setDescription('إدارة الطلبات والحماية والسيرفرات والإحصائيات.').addFields({name:'قيد الانتظار',value:String(s.pending)},{name:'السيرفرات',value:String(s.servers)},{name:'المحظورون',value:String(s.banned)})],components:[new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('admin_pending').setLabel('طلبات الانتظار').setStyle(ButtonStyle.Primary),new ButtonBuilder().setCustomId('admin_stats').setLabel('الإحصائيات').setStyle(ButtonStyle.Secondary),new ButtonBuilder().setCustomId('admin_questions').setLabel('أسئلة الطلب').setStyle(ButtonStyle.Secondary))],ephemeral:true});
 }
}

async function apply(interaction){
 if(interaction.guild) return interaction.reply({content:'ℹ️ أرسل أمر **/apply** في الرسائل الخاصة مع Best.Daod لإرسال طلب الإضافة.',ephemeral:true});
 const db=require('../services/database');
 const qs=db.getApplicationQuestions();
 const modal=new ModalBuilder().setCustomId('apply_questions').setTitle('طلب إضافة Best.Daod');
 modal.addComponents(...qs.slice(0,5).map((q,i)=>new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId(`aq${i+1}`).setLabel(cut(q.question_text,45)).setStyle(q.question_text.includes('سبب')?TextInputStyle.Paragraph:TextInputStyle.Short).setRequired(!!q.required))));
 return interaction.showModal(modal);
}
module.exports={commands:commands.map(c=>c.toJSON()),handleCommand,setupEmbed,setupRow};
