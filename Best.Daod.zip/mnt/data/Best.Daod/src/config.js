require('dotenv').config();

const required = ['DISCORD_TOKEN', 'CLIENT_ID', 'MANAGEMENT_GUILD_ID', 'MANAGEMENT_CHANNEL_ID', 'BOT_OWNER_ID'];
for (const key of required) {
  if (!process.env[key]) console.warn(`تحذير: المتغير ${key} غير مضبوط.`);
}

module.exports = {
  token: process.env.DISCORD_TOKEN,
  clientId: process.env.CLIENT_ID,
  managementGuildId: process.env.MANAGEMENT_GUILD_ID,
  managementChannelId: process.env.MANAGEMENT_CHANNEL_ID,
  botOwnerId: process.env.BOT_OWNER_ID,
  approvedInviteUrl: process.env.APPROVED_INVITE_URL || '',
  debug: process.env.DEBUG === '1'
};
