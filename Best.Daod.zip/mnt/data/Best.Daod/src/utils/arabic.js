function fmtDuration(ms){
  const s=Math.ceil(ms/1000), h=Math.floor(s/3600), m=Math.floor((s%3600)/60), sec=s%60;
  const parts=[]; if(h)parts.push(`${h} ساعة`); if(m)parts.push(`${m} دقيقة`); if(sec||!parts.length)parts.push(`${sec} ثانية`); return parts.join(' و');
}
function cut(s,n=1000){return String(s??'').slice(0,n)}
module.exports={fmtDuration,cut};
