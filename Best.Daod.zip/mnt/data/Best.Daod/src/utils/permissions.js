const { PermissionsBitField } = require('discord.js');
const { getSettings } = require('../services/database');
const { botOwnerId } = require('../config');

function isOwner(userId, guild) { return guild?.ownerId === userId; }
function isBotOwner(userId) { return userId === botOwnerId; }
function isManager(member, guild) {
  if (!member || !guild) return false;
  if (isBotOwner(member.id) || isOwner(member.id,guild)) return true;
  const settings=getSettings(guild.id);
  return !!settings.admin_role_id && member.roles.cache.has(settings.admin_role_id);
}
function hasDangerous(member) { return member?.permissions?.has(PermissionsBitField.Flags.Administrator); }
module.exports={isOwner,isBotOwner,isManager,hasDangerous};
