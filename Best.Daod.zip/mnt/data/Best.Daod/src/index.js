const { Client, GatewayIntentBits, Partials, REST, Routes, Events, EmbedBuilder, PermissionsBitField } = require('discord.js');
const config=require('./config');
const db=require('./services/database');
const commands=require('./commands');
const interactionCreate=require('./events/interactionCreate');
const { observe }=require('./services/security');
const { getSettings, upsertServer, removeServer, log, rejectedCount, banApplicant }=db;

const client=new Client({intents:[GatewayIntentBits.Guilds,GatewayIntentBits.GuildMembers,GatewayIntentBits.GuildMessages,GatewayIntentBits.GuildModeration,GatewayIntentBits.DirectMessages,GatewayIntentBits.MessageContent],partials:[Partials.Channel]});

async function registerCommands(){
 const rest=new REST({version:'10'}).setToken(config.token); await rest.put(Routes.applicationCommands(config.clientId),{body:commands.commands}); console.log('تم تسجيل أوامر Best.Daod.');
}

client.once(Events.ClientReady,async c=>{
 console.log(`Best.Daod متصل باسم ${c.user.tag}`); c.user.setPresence({activities:[{name:'Best.Daod | TEAM MAJID',type:0}],status:'online'}); for(const g of c.guilds.cache.values()) upsertServer(g);
});

client.on(Events.GuildCreate,async guild=>{
 const approved=db.db.prepare("SELECT 1 FROM applications WHERE server_id=? AND status='approved' ORDER BY decided_at DESC LIMIT 1").get(guild.id);
 if(!approved){ const owner=await guild.fetchOwner().catch(()=>null); owner?.send('🚫 هذا السيرفر غير مصرح له باستخدام Best.Daod حاليًا. يجب تقديم طلب `/apply` وانتظار الموافقة قبل إضافة البوت.').catch(()=>{}); await guild.leave().catch(()=>{}); return; }
 upsertServer(guild); log(guild.id,null,'bot_added','تمت إضافة Best.Daod إلى السيرفر بعد الموافقة.');
});
client.on(Events.GuildDelete,g=>{ removeServer(g.id); log(g.id,null,'bot_removed','تمت إزالة Best.Daod من السيرفر.'); });
client.on(Events.InteractionCreate,i=>interactionCreate(i,client));

client.on(Events.GuildMemberAdd,async member=>{
 const s=getSettings(member.guild.id); if(s.welcome_enabled){ const ch=s.welcome_channel_id?member.guild.channels.cache.get(s.welcome_channel_id):member.guild.systemChannel; if(ch) ch.send((s.welcome_message||'👋 أهلاً بك {member} في {server}!').replaceAll('{member}',`<@${member.id}>`).replaceAll('{server}',member.guild.name)).catch(()=>{}); }
 if(s.verification_enabled && s.verification_role_id){ await member.roles.add(s.verification_role_id).catch(()=>{}); }
 if(s.anti_fake_enabled){ const age=Date.now()-member.user.createdTimestamp; if(age<7*24*60*60*1000) log(member.guild.id,member.id,'anti_fake_flag','حساب حديث يحتاج مراجعة.'); }
});
client.on(Events.GuildMemberRemove,member=>{ const s=getSettings(member.guild.id); if(s.goodbye_enabled){ const ch=s.welcome_channel_id?member.guild.channels.cache.get(s.welcome_channel_id):member.guild.systemChannel; ch?.send((s.goodbye_message||'👋 غادرنا {member}.').replaceAll('{member}',member.user.tag).replaceAll('{server}',member.guild.name)).catch(()=>{}); }});

client.on(Events.ChannelDelete,async ch=>{ if(ch.guild) await observe(ch.guild,'channelDelete',null,`تم حذف القناة ${ch.name}`,client); });
client.on(Events.RoleDelete,async role=>{ await observe(role.guild,'roleDelete',null,`تم حذف الرتبة ${role.name}`,client); });
client.on(Events.GuildBanAdd,async ban=>{ await observe(ban.guild,'memberBan',null,`تم حظر ${ban.user.tag}`,client); });
client.on(Events.GuildMemberRemove,async member=>{});
client.on(Events.GuildUpdate,async (oldG,newG)=>{ if(oldG.name!==newG.name) await observe(newG,'permissionUpdate',null,`تغيير اسم السيرفر`,client); });

// رفض الطلب للمرة الثانية يؤدي للحظر من الطلب الثالث.
async function onRejection(appId,adminId,reason){
 const app=db.getApplication(appId); if(!app) return; db.updateApplicationDecision(appId,'rejected',adminId,reason); const count=rejectedCount(app.applicant_id); if(count>=2) banApplicant(app.applicant_id,'تم رفض طلبين سابقين',adminId); }
client.on('error',e=>console.error('Discord error:',e));
process.on('unhandledRejection',e=>console.error('Unhandled:',e));

(async()=>{ if(!config.token){console.error('ضع DISCORD_TOKEN في .env'); process.exit(1);} await registerCommands(); await client.login(config.token); })();
