const { EmbedBuilder } = require('discord.js');
const { getSettings, security } = require('./database');
const { isManager } = require('../utils/permissions');

const bursts = new Map();
const protection = new Map();

function mark(guildId, key, actorId, details) {
  const now=Date.now(); const k=`${guildId}:${key}`;
  const arr=(bursts.get(k)||[]).filter(x=>now-x.t<15000); arr.push({t:now,actorId,details}); bursts.set(k,arr);
  return arr;
}

async function trigger(guild, actorId, eventType, details, client) {
  const settings=getSettings(guild.id);
  security(guild.id,actorId,eventType,'خطير',details);
  if (!settings.protection_enabled) return;
  protection.set(guild.id,{active:true,reason:eventType,at:Date.now()});
  const embed=new EmbedBuilder().setTitle('🚨 تنبيه أمني خطير').setDescription(`تم اكتشاف نشاط خطير في **${guild.name}**.`).addFields({name:'النوع',value:eventType},{name:'التفاصيل',value:String(details).slice(0,1000)},{name:'الإجراء',value:'تم تفعيل وضع الحماية مؤقتًا.'}).setTimestamp();
  const targets=guild.members.cache.filter(m=>!m.user.bot && isManager(m,guild));
  const channelId=settings.logs_channel_id;
  const channel=channelId ? guild.channels.cache.get(channelId) : null;
  for(let i=0;i<5;i++){
    setTimeout(()=>targets.forEach(m=>m.send({embeds:[embed]}).catch(()=>{})),i*10000);
    setTimeout(()=>channel?.send({embeds:[embed]}).catch(()=>{}),i*10000);
  }
}

async function observe(guild, eventType, actorId, details, client) {
  const arr=mark(guild.id,eventType,actorId,details);
  const dangerous=['channelDelete','roleDelete','memberKick','memberBan','roleCreate','permissionUpdate','massAction'];
  const threshold=dangerous.includes(eventType)?3:4;
  if(arr.length>=threshold) await trigger(guild,actorId,eventType,details,client);
}

function isProtectionActive(guildId){ return protection.get(guildId)?.active===true; }
function deactivateProtection(guildId){ protection.delete(guildId); }
module.exports={observe,isProtectionActive,deactivateProtection,trigger};
