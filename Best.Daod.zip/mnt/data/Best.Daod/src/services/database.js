const Database = require('better-sqlite3');
const fs = require('fs');
const path = require('path');

const dataDir = path.join(__dirname, '../../data');
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, 'best-daod.sqlite'));
db.pragma('journal_mode = WAL');

db.exec(`
CREATE TABLE IF NOT EXISTS applications (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 applicant_id TEXT NOT NULL,
 username TEXT NOT NULL,
 server_name TEXT NOT NULL,
 server_id TEXT NOT NULL,
 server_owner TEXT NOT NULL,
 member_count INTEGER DEFAULT 0,
 created_at TEXT NOT NULL,
 reason TEXT NOT NULL,
 invite_link TEXT,
 bot_status TEXT,
 notes TEXT,
 status TEXT NOT NULL DEFAULT 'pending',
 decided_by TEXT,
 decision_reason TEXT,
 decided_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_applicant_created ON applications(applicant_id, created_at);
CREATE INDEX IF NOT EXISTS idx_app_status ON applications(status);

CREATE TABLE IF NOT EXISTS application_questions (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 question_text TEXT NOT NULL,
 required INTEGER NOT NULL DEFAULT 1,
 sort_order INTEGER NOT NULL DEFAULT 0,
 enabled INTEGER NOT NULL DEFAULT 1
);
INSERT INTO application_questions(question_text,required,sort_order) SELECT 'اسم السيرفر',1,1 WHERE NOT EXISTS (SELECT 1 FROM application_questions);
INSERT INTO application_questions(question_text,required,sort_order) SELECT 'معرّف السيرفر',1,2 WHERE (SELECT COUNT(*) FROM application_questions)=1;
INSERT INTO application_questions(question_text,required,sort_order) SELECT 'مالك السيرفر',1,3 WHERE (SELECT COUNT(*) FROM application_questions)=2;
INSERT INTO application_questions(question_text,required,sort_order) SELECT 'عدد الأعضاء',1,4 WHERE (SELECT COUNT(*) FROM application_questions)=3;
INSERT INTO application_questions(question_text,required,sort_order) SELECT 'سبب طلب إضافة البوت',1,5 WHERE (SELECT COUNT(*) FROM application_questions)=4;

CREATE TABLE IF NOT EXISTS applicant_bans (
 applicant_id TEXT PRIMARY KEY,
 reason TEXT NOT NULL,
 banned_by TEXT,
 banned_at TEXT NOT NULL,
 active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS servers (
 guild_id TEXT PRIMARY KEY,
 name TEXT NOT NULL,
 owner_id TEXT,
 member_count INTEGER DEFAULT 0,
 added_at TEXT NOT NULL,
 bot_status TEXT NOT NULL DEFAULT 'online',
 invite_link TEXT
);

CREATE TABLE IF NOT EXISTS settings (
 guild_id TEXT PRIMARY KEY,
 command_channel_id TEXT,
 logs_channel_id TEXT,
 admin_role_id TEXT,
 maintenance INTEGER NOT NULL DEFAULT 0,
 protection_enabled INTEGER NOT NULL DEFAULT 1,
 welcome_enabled INTEGER NOT NULL DEFAULT 0,
 goodbye_enabled INTEGER NOT NULL DEFAULT 0,
 verification_enabled INTEGER NOT NULL DEFAULT 0,
 anti_fake_enabled INTEGER NOT NULL DEFAULT 0,
 welcome_channel_id TEXT,
 verification_channel_id TEXT,
 verification_role_id TEXT,
 welcome_message TEXT,
 goodbye_message TEXT
);

CREATE TABLE IF NOT EXISTS ticket_types (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 guild_id TEXT NOT NULL,
 name TEXT NOT NULL,
 description TEXT,
 category_id TEXT,
 form_json TEXT NOT NULL DEFAULT '[]',
 permissions_json TEXT NOT NULL DEFAULT '{}',
 enabled INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_ticket_types_guild ON ticket_types(guild_id);

CREATE TABLE IF NOT EXISTS tickets (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 guild_id TEXT NOT NULL,
 channel_id TEXT UNIQUE,
 type_id INTEGER,
 opener_id TEXT NOT NULL,
 claimer_id TEXT,
 status TEXT NOT NULL DEFAULT 'open',
 priority INTEGER NOT NULL DEFAULT 0,
 queue_position INTEGER,
 created_at TEXT NOT NULL,
 claimed_at TEXT,
 closed_at TEXT,
 closed_by TEXT,
 rating INTEGER,
 rated_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_tickets_guild_status ON tickets(guild_id, status);

CREATE TABLE IF NOT EXISTS ticket_members (
 ticket_id INTEGER NOT NULL,
 user_id TEXT NOT NULL,
 added_by TEXT NOT NULL,
 added_at TEXT NOT NULL,
 PRIMARY KEY(ticket_id,user_id)
);

CREATE TABLE IF NOT EXISTS ticket_events (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 ticket_id INTEGER NOT NULL,
 actor_id TEXT,
 event_type TEXT NOT NULL,
 details TEXT,
 created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS logs (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 guild_id TEXT,
 actor_id TEXT,
 event_type TEXT NOT NULL,
 details TEXT,
 created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_logs_guild_time ON logs(guild_id, created_at);

CREATE TABLE IF NOT EXISTS security_events (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 guild_id TEXT,
 actor_id TEXT,
 event_type TEXT NOT NULL,
 severity TEXT NOT NULL,
 details TEXT,
 created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS announcements (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 title TEXT NOT NULL,
 content TEXT NOT NULL,
 link TEXT,
 created_by TEXT NOT NULL,
 created_at TEXT NOT NULL
);
`);

try { db.prepare("ALTER TABLE applications ADD COLUMN answers_json TEXT DEFAULT '{}'").run(); } catch {}

const now = () => new Date().toISOString();

module.exports = {
  db,
  now,
  getSettings(guildId) {
    let row = db.prepare('SELECT * FROM settings WHERE guild_id=?').get(guildId);
    if (!row) {
      db.prepare('INSERT INTO settings(guild_id) VALUES(?)').run(guildId);
      row = db.prepare('SELECT * FROM settings WHERE guild_id=?').get(guildId);
    }
    return row;
  },
  updateSettings(guildId, patch) {
    const allowed = ['command_channel_id','logs_channel_id','admin_role_id','maintenance','protection_enabled','welcome_enabled','goodbye_enabled','verification_enabled','anti_fake_enabled','welcome_channel_id','verification_channel_id','verification_role_id','welcome_message','goodbye_message'];
    const keys = Object.keys(patch).filter(k => allowed.includes(k));
    if (!keys.length) return this.getSettings(guildId);
    const set = keys.map(k => `${k}=@${k}`).join(', ');
    db.prepare(`INSERT INTO settings(guild_id) VALUES(@guild_id) ON CONFLICT(guild_id) DO UPDATE SET ${set}`).run({ guild_id:guildId, ...patch });
    return this.getSettings(guildId);
  },
  upsertServer(guild) {
    db.prepare(`INSERT INTO servers(guild_id,name,owner_id,member_count,added_at,bot_status)
      VALUES(@id,@name,@owner,@count,@at,'online')
      ON CONFLICT(guild_id) DO UPDATE SET name=@name,owner_id=@owner,member_count=@count,bot_status='online'`).run({id:guild.id,name:guild.name,owner:guild.ownerId,count:guild.memberCount,at:now()});
    this.getSettings(guild.id);
  },
  removeServer(guildId) { db.prepare('DELETE FROM servers WHERE guild_id=?').run(guildId); },
  getServer(guildId) { return db.prepare('SELECT * FROM servers WHERE guild_id=?').get(guildId); },
  createApplication(data) {
    const stmt = db.prepare(`INSERT INTO applications(applicant_id,username,server_name,server_id,server_owner,member_count,created_at,reason,invite_link,bot_status,notes,answers_json)
      VALUES(@applicant_id,@username,@server_name,@server_id,@server_owner,@member_count,@created_at,@reason,@invite_link,@bot_status,@notes,@answers_json)`);
    const info=stmt.run({...data,created_at:now()}); return db.prepare('SELECT * FROM applications WHERE id=?').get(info.lastInsertRowid);
  },
  getApplicationQuestions() { return db.prepare('SELECT * FROM application_questions WHERE enabled=1 ORDER BY sort_order,id').all(); },
  replaceApplicationQuestions(items) { const tx=db.transaction(()=>{ db.prepare('UPDATE application_questions SET enabled=0').run(); const ins=db.prepare('INSERT INTO application_questions(question_text,required,sort_order,enabled) VALUES(?,?,?,1)'); items.forEach((q,i)=>ins.run(q.text, q.required?1:0, i+1)); }); tx(); },
  getLastApplicationByApplicant(applicantId) { return db.prepare('SELECT * FROM applications WHERE applicant_id=? ORDER BY created_at DESC LIMIT 1').get(applicantId); },
  countRecentApplications(applicantId, minutes) { return db.prepare("SELECT COUNT(*) c FROM applications WHERE applicant_id=? AND created_at>=datetime('now', ?)").get(applicantId, `-${minutes} minutes`).c; },
  getApplication(id) { return db.prepare('SELECT * FROM applications WHERE id=?').get(id); },
  listApplications(status) { return db.prepare('SELECT * FROM applications WHERE status=? ORDER BY created_at DESC').all(status); },
  updateApplicationDecision(id, status, by, reason='') { db.prepare('UPDATE applications SET status=?,decided_by=?,decision_reason=?,decided_at=? WHERE id=?').run(status,by,reason,now(),id); },
  rejectedCount(applicantId) { return db.prepare("SELECT COUNT(*) c FROM applications WHERE applicant_id=? AND status='rejected'").get(applicantId).c; },
  isBanned(applicantId) { return !!db.prepare('SELECT 1 FROM applicant_bans WHERE applicant_id=? AND active=1').get(applicantId); },
  banApplicant(applicantId,reason,by) { db.prepare(`INSERT INTO applicant_bans(applicant_id,reason,banned_by,banned_at,active) VALUES(?,?,?,?,1) ON CONFLICT(applicant_id) DO UPDATE SET reason=excluded.reason,banned_by=excluded.banned_by,banned_at=excluded.banned_at,active=1`).run(applicantId,reason,by,now()); },
  unbanApplicant(applicantId) { db.prepare('UPDATE applicant_bans SET active=0 WHERE applicant_id=?').run(applicantId); },
  log(guildId,actorId,eventType,details='') { db.prepare('INSERT INTO logs(guild_id,actor_id,event_type,details,created_at) VALUES(?,?,?,?,?)').run(guildId,actorId,eventType,details,now()); },
  security(guildId,actorId,eventType,severity,details='') { db.prepare('INSERT INTO security_events(guild_id,actor_id,event_type,severity,details,created_at) VALUES(?,?,?,?,?,?)').run(guildId,actorId,eventType,severity,details,now()); },
  createTicketType(data) { const i=db.prepare('INSERT INTO ticket_types(guild_id,name,description,category_id,form_json,permissions_json) VALUES(?,?,?,?,?,?)').run(data.guild_id,data.name,data.description||'',data.category_id||null,JSON.stringify(data.form||[]),JSON.stringify(data.permissions||{})); return db.prepare('SELECT * FROM ticket_types WHERE id=?').get(i.lastInsertRowid); },
  listTicketTypes(guildId) { return db.prepare('SELECT * FROM ticket_types WHERE guild_id=? AND enabled=1 ORDER BY id').all(guildId); },
  createTicket(data) { const i=db.prepare('INSERT INTO tickets(guild_id,type_id,opener_id,status,priority,queue_position,created_at) VALUES(?,?,?,?,?,?,?)').run(data.guild_id,data.type_id,data.opener_id,data.status||'open',data.priority||0,data.queue_position||null,now()); return db.prepare('SELECT * FROM tickets WHERE id=?').get(i.lastInsertRowid); },
  setTicketChannel(ticketId,channelId) { db.prepare('UPDATE tickets SET channel_id=? WHERE id=?').run(channelId,ticketId); },
  getTicketByChannel(channelId) { return db.prepare('SELECT * FROM tickets WHERE channel_id=?').get(channelId); },
  openTicketCount(guildId) { return db.prepare("SELECT COUNT(*) c FROM tickets WHERE guild_id=? AND status IN ('open','claimed','queued')").get(guildId).c; },
  claimTicket(ticketId,userId) { db.prepare("UPDATE tickets SET claimer_id=?,status='claimed',claimed_at=? WHERE id=? AND claimer_id IS NULL AND status='open'").run(userId,now(),ticketId); },
  closeTicket(ticketId,userId) { db.prepare("UPDATE tickets SET status='closed',closed_at=?,closed_by=? WHERE id=?").run(now(),userId,ticketId); },
  queuedTicketCount(guildId) { return db.prepare("SELECT COUNT(*) c FROM tickets WHERE guild_id=? AND status='queued'").get(guildId).c; },
  nextQueuedTicket(guildId) { return db.prepare("SELECT * FROM tickets WHERE guild_id=? AND status='queued' ORDER BY priority DESC, queue_position ASC, created_at ASC LIMIT 1").get(guildId); },
  activateQueuedTicket(ticketId) { db.prepare("UPDATE tickets SET status='open',queue_position=NULL WHERE id=?").run(ticketId); },
  ticketEvent(ticketId,actorId,eventType,details='') { db.prepare('INSERT INTO ticket_events(ticket_id,actor_id,event_type,details,created_at) VALUES(?,?,?,?,?)').run(ticketId,actorId,eventType,details,now()); },
  addTicketMember(ticketId,userId,by) { db.prepare('INSERT OR IGNORE INTO ticket_members(ticket_id,user_id,added_by,added_at) VALUES(?,?,?,?)').run(ticketId,userId,by,now()); },
  rateTicket(ticketId,rating) { db.prepare('UPDATE tickets SET rating=?,rated_at=? WHERE id=? AND status=\'closed\'').run(rating,now(),ticketId); },
  getStats() { return { applications:db.prepare('SELECT COUNT(*) c FROM applications').get().c, servers:db.prepare('SELECT COUNT(*) c FROM servers').get().c, pending:db.prepare("SELECT COUNT(*) c FROM applications WHERE status='pending'").get().c, approved:db.prepare("SELECT COUNT(*) c FROM applications WHERE status='approved'").get().c, rejected:db.prepare("SELECT COUNT(*) c FROM applications WHERE status='rejected'").get().c, banned:db.prepare('SELECT COUNT(*) c FROM applicant_bans WHERE active=1').get().c }; }
};
