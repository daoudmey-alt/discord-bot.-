const { ChannelType, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const db=require('./database');

async function createTicket(guild, member, typeId) {
  const type=db.db.prepare('SELECT * FROM ticket_types WHERE id=? AND guild_id=? AND enabled=1').get(typeId,guild.id);
  if(!type) throw new Error('نوع التذكرة غير موجود.');
  const count=db.openTicketCount(guild.id);
  const max=20;
  if(count>=max){ const pos=db.queuedTicketCount(guild.id)+1; const ticket=db.createTicket({guild_id:guild.id,type_id:type.id,opener_id:member.id,status:'queued',queue_position:pos}); db.ticketEvent(ticket.id,member.id,'queue',`موضع الانتظار: ${pos}`); return {queued:true,ticket,position:pos}; }
  const ticket=db.createTicket({guild_id:guild.id,type_id:type.id,opener_id:member.id});
  const parent=type.category_id ? guild.channels.cache.get(type.category_id) : null;
  const channel=await guild.channels.create({name:`تذكرة-${ticket.id}`,type:ChannelType.GuildText,parent:parent?.id,permissionOverwrites:[
    {id:guild.roles.everyone.id,deny:[PermissionFlagsBits.ViewChannel]},
    {id:member.id,allow:[PermissionFlagsBits.ViewChannel,PermissionFlagsBits.SendMessages,PermissionFlagsBits.ReadMessageHistory]},
    ...(guild.members.me?[{id:guild.members.me.id,allow:[PermissionFlagsBits.ViewChannel,PermissionFlagsBits.SendMessages,PermissionFlagsBits.ManageChannels,PermissionFlagsBits.ReadMessageHistory]}]:[])
  ]});
  db.setTicketChannel(ticket.id,channel.id);
  db.ticketEvent(ticket.id,member.id,'create',`نوع التذكرة: ${type.name}`);
  const row=new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('ticket_claim').setLabel('استلام التذكرة').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('ticket_add').setLabel('إضافة عضو').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('ticket_transcript').setLabel('حفظ السجل').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('ticket_close').setLabel('إغلاق التذكرة').setStyle(ButtonStyle.Danger)
  );
  const questions=JSON.parse(type.form_json||'[]');
  const embed=new EmbedBuilder().setTitle(`🎫 ${type.name}`).setDescription(type.description||'تم إنشاء التذكرة. اكتب التفاصيل المطلوبة هنا.').addFields({name:'صاحب التذكرة',value:`<@${member.id}>`},{name:'رقم التذكرة',value:`#${ticket.id}`});
  if(questions.length) embed.addFields({name:'الأسئلة المطلوبة',value:questions.map((q,i)=>`${i+1}. ${q}`).join('\n').slice(0,1000)});
  await channel.send({content:`<@${member.id}>`,embeds:[embed],components:[row]});
  return {queued:false,ticket,channel};
}

module.exports={createTicket};
