const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelSelectMenuBuilder, RoleSelectMenuBuilder, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const db=require('../services/database');
const { handleCommand, setupEmbed, setupRow }=require('../commands');
const { isManager, isBotOwner }=require('../utils/permissions');
const { fmtDuration,cut }=require('../utils/arabic');
const { createTicket }=require('../services/tickets');
const config=require('../config');
const confirmations=new Map();
const pendingApplications=new Map();

module.exports=async function(interaction,client){
 try{
  if(interaction.isChatInputCommand()) return handleCommand(interaction);
  if(interaction.isStringSelectMenu() && interaction.customId==='ticket_type_select'){
    if(!interaction.guild) return;
    const settings=db.getSettings(interaction.guild.id);
    if(settings.maintenance) return interaction.reply({content:'🛠️ السيرفر في وضع الصيانة حاليًا. لا يمكن فتح تذاكر جديدة.',ephemeral:true});
    const typeId=Number(interaction.values[0]);
    const result=await createTicket(interaction.guild,interaction.member,typeId);
    return interaction.reply({content:result.queued?`⏳ وصل السيرفر إلى الحد الأقصى للتذاكر المفتوحة حاليًا. تمت إضافة طلبك إلى قائمة الانتظار في المركز **${result.position}**.`:`✅ تم إنشاء تذكرتك ${result.channel}.`,ephemeral:true});
  }
  if(interaction.isButton()){
   const id=interaction.customId;
   if(id.startsWith('setup_')){
    if(!interaction.guild||!isManager(interaction.member,interaction.guild)) return interaction.reply({content:'❌ لا تملك صلاحية إعداد Best.Daod.',ephemeral:true});
    if(id==='setup_command'){
      const m=new ChannelSelectMenuBuilder().setCustomId('pick_command').setPlaceholder('اختر قناة الأوامر').setChannelTypes(0); return interaction.reply({content:'اختر قناة الأوامر:',components:[new ActionRowBuilder().addComponents(m)],ephemeral:true});
    }
    if(id==='setup_logs'){
      const m=new ChannelSelectMenuBuilder().setCustomId('pick_logs').setPlaceholder('اختر قناة السجلات').setChannelTypes(0); return interaction.reply({content:'اختر قناة السجلات:',components:[new ActionRowBuilder().addComponents(m)],ephemeral:true});
    }
    if(id==='setup_role'){
      const m=new RoleSelectMenuBuilder().setCustomId('pick_role').setPlaceholder('اختر رتبة إدارة Best.Daod'); return interaction.reply({content:'اختر رتبة الإدارة:',components:[new ActionRowBuilder().addComponents(m)],ephemeral:true});
    }
    if(id==='setup_reset'){
      const key=`reset:${interaction.guild.id}:${interaction.user.id}`; confirmations.set(key,{step:0,at:Date.now()}); return interaction.reply({content:'⚠️ إعادة الإعداد لا تحذف التذاكر أو السجلات أو الطلبات، لكنها ستعيد إعدادات السيرفر. يجب تأكيد العملية 3 مرات، وبين كل تأكيد 10 ثوانٍ.',components:[new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('confirm_reset_1').setLabel('تأكيد إعادة الإعداد (1/3)').setStyle(ButtonStyle.Danger))],ephemeral:true});
    }
    if(id.startsWith('confirm_reset_')){
      const key=`reset:${interaction.guild.id}:${interaction.user.id}`; const st=confirmations.get(key); const n=Number(id.slice(-1)); if(!st||n!==st.step+1) return interaction.reply({content:'❌ يجب إكمال التأكيدات بالترتيب.',ephemeral:true});
      if(n>1 && Date.now()-st.at<10000) return interaction.reply({content:`⏳ يجب الانتظار ${Math.ceil((10000-(Date.now()-st.at))/1000)} ثوانٍ قبل التأكيد التالي.`,ephemeral:true});
      st.step=n; st.at=Date.now(); confirmations.set(key,st); if(n<3) return interaction.update({content:`✅ تم التأكيد ${n}/3. انتظر 10 ثوانٍ قبل التأكيد التالي.`,components:[new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`confirm_reset_${n+1}`).setLabel(`تأكيد إعادة الإعداد (${n+1}/3)`).setStyle(ButtonStyle.Danger))]});
      db.updateSettings(interaction.guild.id,{command_channel_id:null,logs_channel_id:null,admin_role_id:null,maintenance:0,welcome_enabled:0,goodbye_enabled:0,verification_enabled:0,anti_fake_enabled:0,welcome_channel_id:null,verification_channel_id:null,verification_role_id:null,welcome_message:null,goodbye_message:null}); db.log(interaction.guild.id,interaction.user.id,'setup_reset','تمت إعادة إعداد السيرفر بعد 3 تأكيدات'); confirmations.delete(key); return interaction.update({content:'🔄 تمت إعادة إعداد Best.Daod. لم يتم حذف التذاكر أو السجلات أو الطلبات.',components:[],embeds:[]});
    }
    if(id==='setup_done'||id==='setup_skip') return interaction.update({content:id==='setup_skip'?'⏭️ تم تخطي الإعداد. يمكنك العودة إلى `/setup` لاحقًا.':'✅ اكتمل إعداد Best.Daod الحالي.',embeds:[setupEmbed(interaction.guild)],components:[setupRow()]});
   }
   if(id==='admin_pending'){
    if(!isBotOwner(interaction.user.id)) return interaction.reply({content:'❌ غير مصرح.',ephemeral:true});
    const apps=db.listApplications('pending').slice(0,10);
    if(!apps.length) return interaction.reply({content:'لا توجد طلبات معلقة حاليًا.',ephemeral:true});
    const text=apps.map(a=>`**#${a.id}** — ${a.server_name} — <@${a.applicant_id}> — ${a.member_count} عضو`).join('\n');
    return interaction.reply({embeds:[new EmbedBuilder().setTitle('🟡 الطلبات المعلقة').setDescription(text).setFooter({text:'استخدم معرف الطلب لاتخاذ القرار عبر لوحة الإدارة.'})],ephemeral:true});
   }
   if(id==='admin_questions'){
    if(!isBotOwner(interaction.user.id)) return interaction.reply({content:'❌ غير مصرح.',ephemeral:true});
    const qs=db.getApplicationQuestions(); const modal=new ModalBuilder().setCustomId('questions_modal').setTitle('تعديل أسئلة طلب الإضافة');
    const rows=qs.slice(0,5).map((q,i)=>new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId(`q${i+1}`).setLabel(`السؤال ${i+1} - اكتب [اختياري] عند الحاجة`).setValue(q.required? q.question_text : `[اختياري] ${q.question_text}`).setStyle(TextInputStyle.Short).setRequired(false)));
    while(rows.length<5) rows.push(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId(`q${rows.length+1}`).setLabel(`السؤال ${rows.length+1}`).setStyle(TextInputStyle.Short).setRequired(false)));
    return interaction.showModal(modal);
   }
   if(id==='admin_stats'){
    if(!isBotOwner(interaction.user.id)) return interaction.reply({content:'❌ غير مصرح.',ephemeral:true});
    const s=db.getStats(); return interaction.reply({content:`📊 الطلبات: ${s.applications}\n🟡 معلقة: ${s.pending}\n🟢 مقبولة: ${s.approved}\n🔴 مرفوضة: ${s.rejected}\n🚫 محظورة: ${s.banned}\n🌐 السيرفرات: ${s.servers}`,ephemeral:true});
   }
   if(id==='confirm_setting'||id==='cancel_setting'){
    const ck=`setting:${interaction.guild.id}:${interaction.user.id}`; const st=confirmations.get(ck); if(!st) return interaction.reply({content:'❌ انتهت عملية التأكيد.',ephemeral:true});
    if(id==='cancel_setting'){confirmations.delete(ck); return interaction.update({content:'❌ تم إلغاء التغيير.',components:[],embeds:[]});}
    db.updateSettings(interaction.guild.id,{[st.kind]:st.value}); db.log(interaction.guild.id,interaction.user.id,'setting_change',`${st.kind}=${st.value}`); confirmations.delete(ck); return interaction.update({content:'✅ تم حفظ التغيير الحساس بعد التأكيد.',components:[],embeds:[]});
   }
   if(id.startsWith('protection_off_')){
    if(!isManager(interaction.member,interaction.guild)) return interaction.reply({content:'❌ غير مصرح.',ephemeral:true}); const key=`prot:${interaction.guild.id}:${interaction.user.id}`; const n=Number(id.slice(-1)); let st=confirmations.get(key); if(n===1){st={step:1,at:Date.now()};confirmations.set(key,st);return interaction.reply({content:'⚠️ إيقاف الحماية يتطلب 3 تأكيدات، وبين كل تأكيد 10 ثوانٍ.',components:[new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('protection_off_2').setLabel('تأكيد إيقاف الحماية (2/3)').setStyle(ButtonStyle.Danger))],ephemeral:true});} if(!st||n!==st.step+1) return interaction.reply({content:'❌ يجب إكمال التأكيدات بالترتيب.',ephemeral:true}); if(Date.now()-st.at<10000)return interaction.reply({content:`⏳ انتظر ${Math.ceil((10000-(Date.now()-st.at))/1000)} ثوانٍ.`,ephemeral:true}); st.step=n;st.at=Date.now();confirmations.set(key,st); if(n<3)return interaction.update({content:`✅ تم التأكيد ${n}/3. انتظر 10 ثوانٍ.`,components:[new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('protection_off_3').setLabel('تأكيد إيقاف الحماية (3/3)').setStyle(ButtonStyle.Danger))]}); db.updateSettings(interaction.guild.id,{protection_enabled:0}); db.log(interaction.guild.id,interaction.user.id,'protection_off','تم إيقاف الحماية بعد 3 تأكيدات'); confirmations.delete(key); return interaction.update({content:'⚠️ تم إيقاف الحماية.',components:[]});
   }
   if(id.startsWith('app_')) return applicationDecision(interaction,id);
   const ticket=db.getTicketByChannel(interaction.channelId);
   if(ticket){
    if(id==='ticket_claim'){
      if(!isManager(interaction.member,interaction.guild)) return interaction.reply({content:'❌ هذا الزر مخصص للإدارة.',ephemeral:true});
      if(ticket.claimer_id) return interaction.reply({content:`⚠️ التذكرة مستلمة بالفعل من <@${ticket.claimer_id}>.`,ephemeral:true});
      db.claimTicket(ticket.id,interaction.user.id); db.ticketEvent(ticket.id,interaction.user.id,'claim'); db.log(interaction.guild.id,interaction.user.id,'ticket_claim',`التذكرة #${ticket.id}`); return interaction.reply(`🧑‍💼 تم استلام التذكرة بواسطة <@${interaction.user.id}>.`);
    }
    if(id==='ticket_add'){
      if(!isManager(interaction.member,interaction.guild)) return interaction.reply({content:'❌ هذا الزر مخصص للإدارة.',ephemeral:true});
      const modal=new ModalBuilder().setCustomId(`add_member:${ticket.id}`).setTitle('إضافة عضو للتذكرة').addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('user_id').setLabel('معرّف العضو').setStyle(TextInputStyle.Short).setRequired(true))); return interaction.showModal(modal);
    }
    if(id==='ticket_transcript') return interaction.reply({content:'📄 تم تسجيل أحداث التذكرة. يمكن ربط قناة حفظ السجلات من إعدادات السيرفر.',ephemeral:true});
    if(id==='ticket_close'){
      if(!isManager(interaction.member,interaction.guild)) return interaction.reply({content:'❌ لا تملك صلاحية إغلاق التذكرة.',ephemeral:true});
      db.closeTicket(ticket.id,interaction.user.id); db.ticketEvent(ticket.id,interaction.user.id,'close'); db.log(interaction.guild.id,interaction.user.id,'ticket_close',`التذكرة #${ticket.id}`); const row=new ActionRowBuilder().addComponents(...[1,2,3,4,5].map(n=>new ButtonBuilder().setCustomId(`ticket_rate:${ticket.id}:${n}`).setLabel(`${n} ⭐`).setStyle(ButtonStyle.Secondary))); await interaction.reply({content:'🔒 تم إغلاق التذكرة. إذا أردت، قيّم الخدمة من 1 إلى 5 نجوم:',components:[row]}); return;
    }
    if(id.startsWith('ticket_rate:')){ const [_,tid,rate]=id.split(':'); const t=db.db.prepare('SELECT * FROM tickets WHERE id=? AND guild_id=?').get(Number(tid),interaction.guild.id); if(!t||t.status!=='closed') return interaction.reply({content:'❌ التذكرة غير متاحة للتقييم.',ephemeral:true}); db.rateTicket(Number(tid),Number(rate)); db.ticketEvent(Number(tid),interaction.user.id,'rating',`${rate}/5`); db.log(interaction.guild.id,interaction.user.id,'ticket_rating',`التذكرة #${tid}: ${rate}/5`); return interaction.update({content:`⭐ شكرًا لك. تم حفظ تقييمك: **${rate}/5**.`,components:[]}); }
   }
  }
  if(interaction.isChannelSelectMenu()){
   if(!interaction.guild||!isManager(interaction.member,interaction.guild)) return interaction.reply({content:'❌ غير مصرح.',ephemeral:true});
   const cid=interaction.values[0]; const key=interaction.customId==='pick_command'?'command_channel_id':'logs_channel_id'; const ck=`setting:${interaction.guild.id}:${interaction.user.id}`; confirmations.set(ck,{kind:key,value:cid,at:Date.now()}); return interaction.update({content:`⚠️ تأكيد تغيير الإعداد الحساس إلى <#${cid}>`,components:[new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('confirm_setting').setLabel('تأكيد الحفظ').setStyle(ButtonStyle.Success),new ButtonBuilder().setCustomId('cancel_setting').setLabel('إلغاء').setStyle(ButtonStyle.Secondary))],embeds:[]});
  }
  if(interaction.isRoleSelectMenu()){
   if(!interaction.guild||!isManager(interaction.member,interaction.guild)) return interaction.reply({content:'❌ غير مصرح.',ephemeral:true});
   const rid=interaction.values[0]; const ck=`setting:${interaction.guild.id}:${interaction.user.id}`; confirmations.set(ck,{kind:'admin_role_id',value:rid,at:Date.now()}); return interaction.update({content:`⚠️ تأكيد تغيير رتبة إدارة Best.Daod إلى <@&${rid}>`,components:[new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('confirm_setting').setLabel('تأكيد الحفظ').setStyle(ButtonStyle.Success),new ButtonBuilder().setCustomId('cancel_setting').setLabel('إلغاء').setStyle(ButtonStyle.Secondary))]});
  }
  if(interaction.isModalSubmit()){
   if(interaction.customId==='apply_questions') return collectApplicationQuestions(interaction);
   if(interaction.customId==='apply_modal') return submitApplication(interaction);
   if(interaction.customId==='questions_modal'){
     if(!isBotOwner(interaction.user.id)) return interaction.reply({content:'❌ غير مصرح.',ephemeral:true});
     const items=[]; for(let i=1;i<=5;i++){ let v=interaction.fields.getTextInputValue(`q${i}`).trim(); if(v){ const optional=v.startsWith('[اختياري]'); if(optional) v=v.replace(/^\[اختياري\]\s*/,''); items.push({text:v,required:!optional}); } }
     if(!items.length) return interaction.reply({content:'❌ يجب إدخال سؤال واحد على الأقل.',ephemeral:true}); db.replaceApplicationQuestions(items); db.log(null,interaction.user.id,'application_questions_update',`تم تحديث ${items.length} أسئلة`); return interaction.reply({content:'✅ تم تحديث أسئلة طلب الإضافة وترتيبها.',ephemeral:true});
   }
   if(interaction.customId.startsWith('reject_modal:')){
     if(!isBotOwner(interaction.user.id)) return interaction.reply({content:'❌ غير مصرح.',ephemeral:true});
     const appId=Number(interaction.customId.split(':')[1]); const app=db.getApplication(appId); if(!app) return interaction.reply({content:'❌ الطلب غير موجود.',ephemeral:true});
     const reason=interaction.fields.getTextInputValue('reason'); db.updateApplicationDecision(appId,'rejected',interaction.user.id,reason); db.log(null,interaction.user.id,'application_rejected',`طلب #${appId}: ${reason}`); const count=db.rejectedCount(app.applicant_id); if(count>=2) db.banApplicant(app.applicant_id,'تم رفض طلبين سابقين',interaction.user.id); const user=await interaction.client.users.fetch(app.applicant_id).catch(()=>null); user?.send(`🔴 تم رفض طلبك **#${appId}**.\nالسبب: ${reason}`+(count>=2?'\n🚫 تم منعك من إرسال طلب ثالث حتى يتم رفع الحظر من إدارة Best.Daod.':'')).catch(()=>{}); return interaction.reply({content:`🔴 تم رفض الطلب #${appId} وتسجيل سبب الرفض.`,ephemeral:true});
   }
   if(interaction.customId.startsWith('add_member:')){
     const ticketId=Number(interaction.customId.split(':')[1]); const uid=interaction.fields.getTextInputValue('user_id').trim(); const member=await interaction.guild.members.fetch(uid).catch(()=>null); if(!member) return interaction.reply({content:'❌ لم يتم العثور على عضو بهذا المعرّف.',ephemeral:true});
     const t=db.db.prepare('SELECT * FROM tickets WHERE id=? AND guild_id=?').get(ticketId,interaction.guild.id); if(!t) return interaction.reply({content:'❌ التذكرة غير موجودة.',ephemeral:true});
     await interaction.channel.permissionOverwrites.edit(member.id,{ViewChannel:true,SendMessages:true,ReadMessageHistory:true}); db.addTicketMember(ticketId,member.id,interaction.user.id); db.ticketEvent(ticketId,interaction.user.id,'add_member',member.id); return interaction.reply(`➕ تمت إضافة <@${member.id}> إلى التذكرة.`);
   }
  }
 }catch(e){ console.error(e); if(interaction.replied||interaction.deferred) interaction.followUp({content:'❌ حدث خطأ غير متوقع. تم تسجيل الخطأ.',ephemeral:true}).catch(()=>{}); else interaction.reply({content:'❌ حدث خطأ غير متوقع. تم تسجيل الخطأ.',ephemeral:true}).catch(()=>{}); }
};

async function collectApplicationQuestions(interaction){
 const uid=interaction.user.id;
 if(db.isBanned(uid)) return interaction.reply({content:'🚫 تم منعك من إرسال طلبات إضافة Best.Daod. إذا كان لديك اعتراض، تواصل مع إدارة Best.Daod.',ephemeral:true});
 const recent=db.getLastApplicationByApplicant(uid);
 if(recent){ const ms=Date.now()-new Date(recent.created_at).getTime(); if(ms<3600000) return interaction.reply({content:`⏳ لا يمكنك إرسال طلب جديد الآن. الوقت المتبقي: **${fmtDuration(3600000-ms)}**.`,ephemeral:true}); }
 const qs=db.getApplicationQuestions(); const answers={}; for(let i=0;i<qs.slice(0,5).length;i++) answers[qs[i].id]=interaction.fields.getTextInputValue(`aq${i+1}`)||'';
 pendingApplications.set(uid,{answers,questions:qs});
 const modal=new ModalBuilder().setCustomId('apply_modal').setTitle('بيانات السيرفر');
 const fields=[['server_name','اسم السيرفر',TextInputStyle.Short],['server_id','معرّف السيرفر',TextInputStyle.Short],['server_owner','مالك السيرفر',TextInputStyle.Short],['member_count','عدد الأعضاء',TextInputStyle.Short],['reason','سبب طلب إضافة البوت',TextInputStyle.Paragraph]];
 modal.addComponents(...fields.map(([id,label,style])=>new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId(id).setLabel(label).setStyle(style).setRequired(true))));
 return interaction.showModal(modal);
}

async function submitApplication(interaction){
 const uid=interaction.user.id; const pending=pendingApplications.get(uid);
 if(!pending) return interaction.reply({content:'❌ انتهت جلسة الطلب. استخدم `/apply` من جديد.',ephemeral:true});
 if(db.isBanned(uid)) return interaction.reply({content:'🚫 تم منعك من إرسال طلبات إضافة Best.Daod.',ephemeral:true});
 const recent=db.getLastApplicationByApplicant(uid); if(recent){ const ms=Date.now()-new Date(recent.created_at).getTime(); if(ms<3600000){pendingApplications.delete(uid);return interaction.reply({content:`⏳ لا يمكنك إرسال طلب جديد الآن. الوقت المتبقي: **${fmtDuration(3600000-ms)}**.`,ephemeral:true}); }}
 const data={applicant_id:uid,username:interaction.user.tag,server_name:interaction.fields.getTextInputValue('server_name'),server_id:interaction.fields.getTextInputValue('server_id'),server_owner:interaction.fields.getTextInputValue('server_owner'),member_count:Number(interaction.fields.getTextInputValue('member_count'))||0,reason:interaction.fields.getTextInputValue('reason'),invite_link:'غير متوفر',bot_status:'غير مضاف بعد',notes:'طلب عبر Discord',answers_json:JSON.stringify(pending.answers)};
 const app=db.createApplication(data); pendingApplications.delete(uid); db.log(null,uid,'application_submit',`طلب #${app.id}`);
 const ch=interaction.client.channels.cache.get(config.managementChannelId); if(ch){ const e=new EmbedBuilder().setTitle('🟡 طلب إضافة Best.Daod جديد').addFields({name:'رقم الطلب',value:`#${app.id}`,inline:true},{name:'المتقدم',value:`<@${uid}>`,inline:true},{name:'السيرفر',value:`${data.server_name}\n${data.server_id}`,inline:true},{name:'المالك',value:data.server_owner,inline:true},{name:'الأعضاء',value:String(data.member_count),inline:true},{name:'السبب',value:cut(data.reason)},{name:'إجابات النموذج',value:cut(Object.entries(pending.answers).map(([id,v])=>`#${id}: ${v||'—'}`).join('\n'),1000)}).setTimestamp(); const row=new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`app_approve:${app.id}`).setLabel('الموافقة').setStyle(ButtonStyle.Success),new ButtonBuilder().setCustomId(`app_reject:${app.id}`).setLabel('رفض').setStyle(ButtonStyle.Danger),new ButtonBuilder().setCustomId(`app_ban:${app.id}`).setLabel('حظر المتقدم').setStyle(ButtonStyle.Secondary)); await ch.send({embeds:[e],components:[row]}); }
 return interaction.reply({content:`✅ تم إرسال طلبك بنجاح. رقم الطلب: **#${app.id}**\nسيتم مراجعة الطلب من إدارة Best.Daod.`,ephemeral:true});
}
async function applicationDecision(interaction,id){
 if(!isBotOwner(interaction.user.id)) return interaction.reply({content:'❌ غير مصرح لك بإدارة طلبات Best.Daod.',ephemeral:true});
 const [action,num]=id.split(':'); const app=db.getApplication(Number(num)); if(!app) return interaction.reply({content:'❌ الطلب غير موجود.',ephemeral:true});
 if(action==='app_approve'){ db.updateApplicationDecision(app.id,'approved',interaction.user.id); db.log(null,interaction.user.id,'application_approved',`طلب #${app.id}`); const user=await interaction.client.users.fetch(app.applicant_id).catch(()=>null); user?.send(`🟢 تمت الموافقة على طلبك **#${app.id}** لإضافة Best.Daod إلى **${app.server_name}**.\nأضف البوت بنفسك من رابط الدعوة المعتمد من الإدارة.`+(config.approvedInviteUrl?`\n${config.approvedInviteUrl}`:'' )).catch(()=>{}); return interaction.update({content:`🟢 تمت الموافقة على الطلب #${app.id} بواسطة <@${interaction.user.id}>.`,embeds:[],components:[]}); }
 if(action==='app_reject'){ const modal=new ModalBuilder().setCustomId(`reject_modal:${app.id}`).setTitle('سبب رفض الطلب').addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('reason').setLabel('سبب الرفض').setStyle(TextInputStyle.Paragraph).setRequired(true))); return interaction.showModal(modal); }
 if(action==='app_ban'){ db.banApplicant(app.applicant_id,'حظر إداري',interaction.user.id); db.updateApplicationDecision(app.id,'banned',interaction.user.id,'حظر إداري'); db.log(null,interaction.user.id,'applicant_ban',`المتقدم ${app.applicant_id}`); return interaction.update({content:`🚫 تم حظر المتقدم المرتبط بالطلب #${app.id}.`,components:[],embeds:[]}); }
}
