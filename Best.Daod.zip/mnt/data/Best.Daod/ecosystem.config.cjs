module.exports = {
  apps: [{
    name: 'Best.Daod',
    script: 'src/index.js',
    cwd: __dirname,
    autorestart: true,
    restart_delay: 5000,
    max_restarts: 20,
    time: true,
    env: { NODE_ENV: 'production' }
  }]
};
